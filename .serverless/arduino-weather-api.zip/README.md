# arduino-weather-api
Node/Lambda based app which makes calls to National Weather service and simplifies responses to optimize data for Arduino processing


## Data source

https://www.weather.gov/documentation/services-web-api